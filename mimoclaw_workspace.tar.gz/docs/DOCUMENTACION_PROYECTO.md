# SassBlum — Ticket Management System
## Documentación Completa del Proyecto

> **Escuela Superior Politécnica del Litoral (ESPOL)**
> **Facultad de Ingeniería Eléctrica y Computación (FIEC)**
> **Ingeniería de Software II — II PAO 2025**
>
> **Equipo:** Erick Armijos, Juan Pérez, Elías Rubio, Jahir Cajas, Jairo Rodríguez
> **Cliente:** SassBlum — Vicky Pinto
> **Instructora:** Dra. Villavicencio / Dr. Mera
> **Fecha:** Junio 2026

---

## 1. Resumen Ejecutivo

El Sistema de Gestión de Tickets SassBlum es una aplicación web full-stack desarrollada para la empresa SassBlum, una compañía de soluciones tecnológicas administrada por Vicky Pinto. El sistema fue construido por un equipo de cinco miembros a lo largo de cuatro sprints siguiendo la metodología SCRUM, y representa un MVP completo listo para producción desplegado usando Docker y Jenkins CI/CD.

La plataforma digitaliza y optimiza el proceso interno de solicitudes de servicio de SassBlum proporcionando un entorno de tickets basado en roles para tres perfiles de usuario: clientes, trabajadores y administradores.

**Objetivos clave logrados:**
1. Eliminar el manejo manual de tickets basado en papel
2. Proporcionar actualizaciones de estado en tiempo real vía WebSockets
3. Forzar un ciclo de vida estructurado de tickets mediante una máquina de estados
4. Entregar notificaciones multicanal (email, in-app, WebSocket)
5. Habilitar exportación de datos (CSV, Excel, PDF) para reportes operativos

**Alcance técnico:** 30+ endpoints REST API, 2 canales WebSocket, frontend React 19 + TypeScript, backend Django 6, Supabase (PostgreSQL 15), Redis para mensajería en tiempo real, y pipeline CI/CD completo.

---

## 2. Contexto del Proyecto y Antecedentes

### 2.1 Cliente y Stakeholders

El cliente es SassBlum, una empresa de servicios tecnológicos cuyo stakeholder principal es **Vicky Pinto** (CEO/Owner). Su rol es crítico: define el catálogo de servicios, aprueba los entregables de cada sprint y asegura que el sistema cumpla los requisitos operativos de la empresa.

### 2.2 Definición del Problema

El proceso anterior de SassBlum para manejar solicitudes de servicio era completamente manual:
- Los clientes llamaban o enviaban mensajes para solicitar servicio
- Las asignaciones se rastreaban informalmente
- Las solicitudes se perdían o olvidaban, sin rastro de auditoría
- No había visibilidad del estado de los tickets para los clientes
- Asignación ineficiente de trabajo, resultando en distribución desigual de carga
- No había datos históricos disponibles para análisis de rendimiento

### 2.3 Objetivos del Proyecto

**Objetivo General:** Diseñar e implementar un sistema web de gestión de tickets multi-rol que digitalice el flujo de trabajo de solicitudes de servicio de SassBlum, asegurando trazabilidad, comunicación en tiempo real y reportes operativos.

**Objetivos Específicos:**
- Implementar un sistema de control de acceso basado en roles (Cliente, Trabajador, Administrador)
- Construir un catálogo de servicios gestionado por administradores y accesible para clientes
- Forzar un ciclo de vida formal de tickets mediante una máquina de estados
- Entregar notificaciones en tiempo real vía email, in-app y WebSockets
- Generar y exportar reportes operativos en formatos CSV, Excel y PDF
- Desplegar la aplicación en un entorno de producción vía Docker y Jenkins

---

## 3. Proceso de Desarrollo y Gestión de Proyecto

### 3.1 Metodología SCRUM

El proyecto siguió estrictamente el marco SCRUM con:
- **Sprint Planning** al inicio de cada sprint
- **Daily Standups** para sincronización
- **Sprint Reviews** con el cliente (Vicky Pinto)
- **Retrospectivas** para mejora continua
- **Transparencia, inspección y adaptación** como principios fundamentales

### 3.2 Roles del Equipo

| Miembro | Rol SCRUM | Responsabilidad Técnica |
|---------|-----------|------------------------|
| Erick Armijos | Developer | Módulo Tickets (FE + BE) + ValidatorFactory |
| Juan Pérez | Scrum Master | Core + Auth (FE + BE) + Integración |
| Elías Rubio | Developer | Notifications + Realtime + SocketClient |
| Jahir Cajas | Developer | Catálogo + Sitio Público + UI Kit |
| Jairo Rodríguez | Product Owner | Reports + Dashboards + DevOps |

### 3.3 Plan de Sprints

| Sprint | Fechas | Módulos | Estado |
|--------|--------|---------|--------|
| Sprint 1 | 25–31 May 2025 | authentication/ (FE + BE) | ✅ Completado |
| Sprint 2 | 15–21 Jun 2025 | catalog/ + tickets/ (creación) | ✅ Completado |
| Sprint 3 | 6–26 Jul 2025 | notifications/ + history + password reset | ✅ Completado |
| Sprint 4 | 27 Jul – 16 Ago 2025 | assignment + reports/ + realtime/ | ✅ Completado |

**Períodos de buffer:** 14 días entre Sprint 1 y 2; 13 días entre Sprint 2 y 3.

### 3.4 Herramientas de Gestión

- **GitHub Projects** para planificación de sprints, seguimiento de issues y monitoreo de progreso
- **Issues etiquetadas** por módulo (auth, tickets, catalog, notifications, reports, devops) y tipo (feat, fix, test, chore)
- **Pull Requests** con al menos 1 reviewer antes de merge
- **Commits convencionales:** `feat(tickets): add TicketStateMachine`

### 3.5 Estructura del Repositorio

```
SassBlumTicketWeb/
├── backend/                    # Django + DRF
│   ├── apps/
│   │   ├── authentication/     # Sprint 1: Users, JWT, RBAC
│   │   ├── catalog/            # Sprint 2: Services CRUD + images
│   │   ├── tickets/            # Sprints 2-4: Ticket lifecycle
│   │   ├── notifications/      # Sprint 3: 3 notification strategies
│   │   ├── reports/            # Sprint 4: KPIs + export
│   │   └── realtime/           # Sprint 4: WebSocket channels
│   ├── core/                   # ABCs, RBAC, factories, exceptions
│   └── config/                 # Settings, URLs, ASGI
├── frontend/                   # React 19 + TypeScript + Vite
│   └── src/
│       ├── core/               # UI kit, hooks, validators, base
│       ├── modules/            # Feature modules by role
│       └── infrastructure/     # ApiClient, SocketClient
├── tests/acceptance/           # 20+ acceptance test cases
├── scripts/                    # Backup, deployment scripts
├── Jenkinsfile                 # CI/CD pipeline (5 stages)
├── docker-compose.yml          # Development
├── docker-compose.prod.yml     # Production
└── AGENTS.md                   # LLM context file
```

### 3.6 Evidencia de Comunicación con el Cliente

Todas las comunicaciones se realizaron vía WhatsApp (principal) y Zoom (presentaciones de sprint):
- Grabaciones de revisiones de sprint (Zoom) para Sprints 1–4
- Hilos de WhatsApp discutiendo cambios de alcance
- Formularios de aceptación firmados por Vicky Pinto al final de cada sprint

---

## 4. Arquitectura del Sistema y Diseño

### 4.1 Visión General

El sistema SassBlum se construye sobre una arquitectura cliente-servidor con énfasis en comunicación RESTful y canales WebSocket en tiempo real.

### 4.2 Arquitectura de Despliegue

El despliegue de producción usa Docker Compose con tres servicios:

| Servicio | Tecnología | Puerto | Rol |
|----------|-----------|--------|-----|
| backend | Python 3.12 / Daphne ASGI | 8000 | REST API + WebSocket |
| frontend | Node 22 / Nginx | 80 | React SPA + static files |
| redis | Redis 7 Alpine | 6379 | Channel layer para Django Channels |

**Nginx** como reverse proxy enruta `/api/` y `/ws/` al backend, sirviendo el build de React como archivos estáticos. HTTPS provisto por Let's Encrypt.

### 4.3 Diagrama de Arquitectura

```
┌─────────────────────────────────────────────────────────────────┐
│                     Internet (HTTPS / WSS)                      │
├───────────────┬──────────────────────┬──────────────────────────┤
│   Clientes    │  Trabajadores        │  Administradores         │
└───────┬───────┴──────────┬───────────┴─────────────┬───────────┘
        │ HTTPS            │ HTTPS                    │ HTTPS
┌───────▼──────────────────▼──────────────────────────▼───────────┐
│                     Nginx Reverse Proxy                          │
│           /api/* → backend:8000   /ws/* → backend:8000           │
└───────────────────────────┬──────────────────────────────────────┘
                            │
┌───────────────────────────▼──────────────────────────────────────┐
│              Django Backend (Daphne ASGI)                        │
│  ┌──────────────┐  ┌────────────┐  ┌────────────┐               │
│  │ REST API     │  │ Channels   │  │ Django     │               │
│  │ (DRF)       │  │ (WebSocket)│  │ Admin      │               │
│  └──────┬───────┘  └─────┬──────┘  └────────────┘               │
│         │                │                                       │
│  ┌──────▼────────────────▼──────┐  ┌───────────────────────────┐ │
│  │  Supabase PostgreSQL 15      │  │  Redis 7 (Channel Layer)  │ │
│  └──────────────────────────────┘  └───────────────────────────┘ │
└──────────────────────────────────────────────────────────────────┘
```

### 4.4 Justificación de Decisiones Arquitectónicas

| Decisión | Justificación |
|----------|--------------|
| Django 6 + DRF | Robusto, batteries-included, ORM potente, DRF para REST API |
| React 19 + TypeScript | Ecosistema maduro, type safety, component model |
| Supabase (PostgreSQL) | Managed, escalable, backup automático |
| Redis + Channels | Real-time via WebSockets, pub/sub para notificaciones |
| Docker Compose | Consistencia dev/prod, fácil deployment |
| Nginx | Reverse proxy, static files, SSL termination |
| Jenkins + GitHub Actions | CI/CD automatizado, PR gating |

### 4.5 Autenticación y Control de Acceso

**JWT** con djangorestframework-simplejwt:
- Access tokens en memoria (nunca localStorage — previene XSS)
- Refresh tokens con device fingerprinting
- Rotación de tokens + blacklist en logout

**RBAC** mediante tres clases de permisos DRF:
- `IsClient` → role == 'client' AND estado == 'activo'
- `IsWorker` → role == 'worker' AND estado == 'activo'
- `IsAdmin` → role == 'admin' AND is_active == True

### 4.6 Principios SOLID

| Principio | Implementación |
|-----------|---------------|
| **SRP** | Un serializer por operación; un validador por regla; modelos solo datos; servicios solo lógica; views solo orquestan HTTP |
| **OCP** | Nuevos validadores = nuevo nodo en la cadena. Nuevos exportadores = nueva clase. Nuevos canales = nueva Strategy |
| **LSP** | Todas las clases concretas son intercambiables con su interfaz |
| **ISP** | ITicketClientActions ≠ ITicketWorkerActions ≠ ITicketAdminActions |
| **DIP** | Todos dependen de interfaces, nunca de clases concretas. Servicios inyectados via providers |

### 4.7 Patrones de Diseño

| Patrón | Aplicación |
|--------|-----------|
| Repository | AuthRepository, TicketRepository, NotificationRepository |
| Factory | ValidatorFactory, ExporterFactory, NotificationFactory |
| Strategy | EmailNotificationStrategy, InAppStrategy, WebSocketStrategy |
| Observer | Django Signals: post_save(TicketEvent) → NotificationService.dispatch() |
| Singleton | AuthService, TicketService, NotificationService (thread-safe con Lock) |
| Chain of Responsibility | EmailValidator → PasswordValidator; BasicFieldValidator → FileValidator → BusinessRuleValidator |
| State Machine | TicketStateMachine: Nuevo → EnProceso → EnEspera → Resuelto → Cerrado |

### 4.8 Prototipo de Alta Fidelidad

Se desarrolló un prototipo en Figma antes de la implementación. Los tokens de diseño establecidos:
- **Color primario:** Navy #0a1628 (brand-navy)
- **Color de acento:** Cyan #00d4ff (brand-cyan)
- **Tipografía:** Inter
- **Animaciones:** Framer Motion (respeta prefers-reduced-motion)

---

## 5. Detalles de Implementación

### 5.1 Endpoints API Principales

| Método | Endpoint | Permiso | Descripción |
|--------|----------|---------|-------------|
| POST | /api/auth/register | Público | Registro de nuevo cliente |
| POST | /api/auth/login | Público | Login, retorna JWT |
| POST | /api/auth/forgot-password | Público | Envía email de recuperación |
| GET | /api/tickets/ | Auth | Lista tickets (filtrado por rol) |
| POST | /api/tickets/ | IsClient | Crear nuevo ticket |
| POST | /api/tickets/:id/status | IsWorker | Actualizar estado + comentario |
| POST | /api/tickets/:id/comments | IsWorker | Agregar comentario |
| POST | /api/tickets/:id/assign | IsAdmin | Asignar a trabajador |
| POST | /api/tickets/:id/reassign | IsAdmin | Reasignar a otro trabajador |
| GET | /api/tickets/:id/ | Auth | Detalle del ticket |
| GET | /api/servicios/ | Público | Catálogo de servicios |
| POST | /api/servicios/admin | IsWorker\|IsAdmin | Crear servicio |
| PATCH | /api/servicios/admin/:id | IsWorker\|IsAdmin | Editar servicio |
| GET | /api/notificaciones/ | Auth | Listar notificaciones |
| PATCH | /api/notificaciones/preferencias/ | Auth | Actualizar preferencias |
| GET | /api/reportes/tickets | IsAdmin | KPIs del dashboard |
| POST | /api/reportes/exportar | IsAdmin | Exportar CSV/PDF/Excel |
| GET | /api/usuarios/ | IsAdmin | Listar usuarios |
| PATCH | /api/usuarios/:id/bloquear | IsAdmin | Bloquear cuenta |
| GET | /health/ | Público | Health check |

### 5.2 Máquina de Estados del Ticket

```
[Nuevo] → [EnProceso] → [EnEspera] → [EnProceso] → [Resuelto] → [Cerrado]
                                                                      ↑
                                                                  (terminal)
```

**Reglas:**
- Nuevo → solo EnProceso (requiere asignación)
- EnProceso → EnEspera o Resuelto
- EnEspera → solo EnProceso
- Resuelto → solo Cerrado
- Cerrado → sin transiciones (terminal)
- Cada transición requiere comentario no vacío (BR-35)

### 5.3 Sistema de Notificaciones

| Canal | Tecnología | Estrategia |
|-------|-----------|------------|
| Email | SMTP / Django Signals | EmailNotificationStrategy |
| In-App | PostgreSQL / REST API | InAppNotificationStrategy |
| Real-Time | Django Channels / Redis | WebSocketStrategy |
| Preferencias | React Hooks / User Settings | Toggle por usuario (Email/App/WS) |

### 5.4 Estándares de Código

**Backend (Python):**
- snake_case para variables/funciones, PascalCase para clases
- Type hints en todas las firmas de función
- Imports absolutos desde la raíz del proyecto
- Tests con pytest + DRF APIClient

**Frontend (TypeScript):**
- camelCase para variables/funciones, PascalCase para componentes
- Un componente por archivo, export named
- Sin tipos `any`, usar `unknown` + type guards
- Tailwind CSS para estilos, tokens de diseño en index.css

---

## 6. Testing y Aseguramiento de Calidad

### 6.1 Estrategia de Testing

| Nivel | Backend | Frontend |
|-------|---------|----------|
| Unit Tests | pytest (state machine, validators, services) | Vitest (components, hooks) |
| Integration Tests | DRF APIClient (HTTP endpoints) | @testing-library/react |
| Acceptance Tests | 20+ test cases (TC-C1..TC-A6) | - |
| E2E Tests | - | Pendiente (Cypress/Playwright) |
| Static Analysis | SonarQube + flake8 | ESLint + tsc --noEmit |

### 6.2 Casos de Prueba de Aceptación (20 del Template FIEC)

#### CLIENT (TC-C1 a TC-C8)

| ID | Historia | Criterio de Aceptación (Given/When/Then) |
|----|----------|----------------------------------------|
| TC-C1 | HU-02 Registro | Given un email nuevo, when el cliente se registra, then la cuenta se crea como "pendiente" y se envía email de verificación |
| TC-C2 | HU-03 Verificación | Given el link de verificación, when se abre, then la cuenta se activa. Forgot/Reset emite token de uso único con 1 hora de validez |
| TC-C3 | HU-01 Login | Given credenciales válidas verificadas, when inicia sesión, then se emite JWT y el usuario llega al dashboard de cliente |
| TC-C4 | HU-04 Crear ticket | Given cliente logueado, when crea ticket (asunto≤80, desc≥10, adj≤5MB), then se crea como "Nuevo" y el Observer dispara notificaciones |
| TC-C5 | HU-06 Visualización | Given un ticket existente, when se abre, then se muestran asunto, servicio, prioridad, badge de estado, metadata y adjuntos |
| TC-C6 | HU-09 Historial | Given un ticket con actividad, when se ve historial, then todos los eventos aparecen cronológicamente con autor y timestamp |
| TC-C7 | HU-10 Filtros | Given la lista de tickets, when se filtra por estado/prioridad, then solo se mueven los tickets que coinciden (paginados) |
| TC-C8 | HU-15/16 Notificaciones | Given notificaciones in-app, when se abre la campana, then se muestran conteo no leídos e historial; preferencias togglean email/in-app/WS |

#### WORKER (TC-W1 a TC-W6)

| ID | Historia | Criterio de Aceptación |
|----|----------|------------------------|
| TC-W1 | HU-01 Login | Given credenciales de worker, when inicia sesión, then el dashboard lista tickets asignados |
| TC-W2 | HU-07 Estado | Given ticket "EnProceso", when se mueve a "EnEspera" con comentario no vacío, then la transición se acepta (BR-35) y el cliente es notificado |
| TC-W3 | HU-11 Comentarios | Given ticket asignado, when se agrega comentario, then se añade al historial |
| TC-W4 | HU-07 Máquina de estados | Given el ciclo de vida, when se transiciona Nuevo→EnProceso→EnEspera→EnProceso→Resuelto, then solo transiciones válidas permitidas (inválidas retornan 422) |
| TC-W5 | HU-12 Cierre | Given ticket "Resuelto", when se cierra, then alcanza estado terminal "Cerrado" y no puede transicionar más |
| TC-W6 | HU-13 Tiempo real | Given detalle de ticket abierto, when otro rol lo cambia, then la vista se actualiza en vivo vía WebSocket |

#### ADMIN (TC-A1 a TC-A6)

| ID | Historia | Criterio de Aceptación |
|----|----------|------------------------|
| TC-A1 | HU-01 Login | Given credenciales admin, when inicia sesión, then el dashboard muestra todos los tickets de todos los clientes |
| TC-A2 | HU-05 Asignación | Given ticket T-2026-9001 en "Nuevo" (sin asignar), when se asigna a worker activo, then estado cambia a "EnProceso" y worker es notificado |
| TC-A3 | HU-08 Reasignación | Given ticket asignado, when se reasigna a otro worker, then el cambio se registra en historial y ambos workers son notificados |
| TC-A4 | HU-17 Reportes | Given datos de tickets, when se genera reporte con filtros de fecha/estado, then KPIs y gráficos se renderizan |
| TC-A5 | HU-18 Exportación | Given un reporte, when se exporta, then archivo CSV/PDF/Excel se descarga correctamente |
| TC-A6 | HU-14 Usuarios | Given página de admin de usuarios, when se crea/bloquea/desbloquea usuario, then el cambio persiste; usuario bloqueado no puede login |

### 6.3 Tests Adicionales de Seguridad

| ID | Escenario | Resultado Esperado |
|----|-----------|-------------------|
| SEC-01 | Acceso sin autenticación | 401 en endpoints protegidos |
| SEC-02 | Health check público | 200 + status "healthy" |
| SEC-03 | Inyección SQL en login | Manejado safely, 400/401 |
| SEC-04 | XSS en asunto de ticket | HTML escapado o rechazado |
| SEC-05 | Password no en respuestas | Hash nunca visible en API |
| SEC-06 | Rate limiting en login | 429 después de exceder límite |
| SEC-07 | Endpoints admin requieren rol | 403 para usuarios no admin |

### 6.4 Detección Preemptiva — SonarQube

SonarQube integrado vía `sonar-project.properties`:
- **Proyecto:** edarmijo_SassBlumRedise-oWeb
- **Organización:** edarmijo
- **Análisis:** code smells, security hotspots, cobertura de tests
- **CI/CD:** GitHub Actions corre en cada PR a main

---

## 7. Despliegue y Documentación de Usuario

### 7.1 Resumen de Despliegue

El sistema se despliega usando Docker Compose en un entorno Linux de producción (Ubuntu 22.04+). El pipeline CI/CD es gestionado por Jenkins.

### 7.2 Pipeline Jenkins CI/CD

**5 etapas activas:**
1. **Checkout** — Clonar repositorio
2. **Backend Tests** — Django check + pytest + flake8
3. **Frontend Tests** — TypeScript check + vitest + ESLint
4. **Build Images** — Docker build backend + frontend
5. **Push to Docker Hub** — Upload imágenes con tags

### 7.3 Configuración Local

**Prerrequisitos:** Python 3.12+, Node.js 22+, Docker & Docker Compose v2, Redis

```bash
# Backend
cd backend && python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env  # editar con valores reales
python manage.py migrate && python manage.py createsuperuser
daphne config.asgi:application

# Frontend
cd frontend && npm install && npm run dev

# Docker (full stack)
docker-compose up -d
```

### 7.4 Variables de Entorno Requeridas

| Variable | Requerida | Descripción |
|----------|-----------|-------------|
| DJANGO_SECRET_KEY | Sí | 50+ caracteres aleatorios |
| DJANGO_DEBUG | Sí | False en producción |
| DATABASE_URL | Sí | Cadena de conexión Supabase PostgreSQL |
| REDIS_URL | Sí | redis://redis:6379/0 |
| CORS_ALLOWED_ORIGINS | Sí | Orígenes frontend permitidos |
| ALLOWED_HOSTS | Sí | Hostnames permitidos |
| EMAIL_HOST | Sí | Servidor SMTP |
| EMAIL_HOST_PASSWORD | Sí | Contraseña SMTP |
| FRONTEND_URL | Sí | URL del frontend para links de email |
| SUPABASE_URL | Opcional | Para uploads a Supabase Storage |
| SUPABASE_SERVICE_KEY | Opcional | Service role key (solo backend) |
| VITE_API_BASE_URL | Sí (FE) | URL base de la API |
| VITE_WS_URL | Sí (FE) | URL de WebSocket |

---

## 8. Conclusiones y Trabajo Futuro

### 8.1 Logros

- 18 historias de usuario implementadas y aceptadas por el cliente en 4 sprints
- 30+ endpoints REST API y 2 canales WebSocket desplegados
- Cumplimiento total de SOLID validado al final de cada sprint
- 6 patrones de diseño implementados
- Sistema de notificaciones 3 canales con control de preferencias
- Pipeline CI/CD completo: GitHub Actions + Jenkins
- Integración SonarQube para análisis estático
- UI rediseñada con sistema de diseño consistente (shadcn/ui + Tailwind + Framer Motion)
- **30 hallazgos de auditoría corregidos** (ver REPORTE_AUDITORIA_TOTAL.md)
- **9 de 10 cambios del cliente implementados** (reunión 24 junio 2026)

### 8.2 Limitaciones Identificadas

| Área | Estado | Nota |
|------|--------|------|
| Tests E2E (Cypress) | Pendiente | Requiere setup de Cypress/Playwright |
| Staging environment | Pendiente | Pre-producción en Render/Vercel |
| Backup automatizado | ✅ Script creado | `scripts/backup_db.sh` — configurar cron |
| OpenAPI/Swagger | Pendiente | Documentación automática de API |
| i18n | Pendiente | Internacionalización |

### 8.3 Mejoras Sugeridas

1. Implementar tests E2E con Cypress cubriendo el flujo completo
2. Configurar auto-renovación de certificados Let's Encrypt
3. Escalar backend con múltiples workers Daphne detrás de Nginx upstream
4. Implementar flujo de Reasignación Request: worker solicita → admin aprueba/rechaza
5. Agregar Recharts para visualización de datos en dashboards
6. Configurar Sentry para monitoreo de errores en producción

---

## 9. Referencias

1. Django Documentation — https://docs.djangoproject.com/
2. React Documentation — https://react.dev/
3. Django REST Framework — https://www.django-rest-framework.org/
4. Supabase Documentation — https://supabase.com/docs
5. Django Channels — https://channels.readthedocs.io/
6. Atlassian. "What is Scrum?" — https://www.atlassian.com/agile/scrum
7. Kenneth S. Rubin. "Essential SCRUM" — Addison-Wesley, 2012
8. SonarQube Documentation — https://docs.sonarqube.org/
9. OWASP Top 10 — https://owasp.org/www-project-top-ten/

---

## 10. Contribuciones Individuales

| Miembro | Módulos / Archivos | Contribución |
|---------|-------------------|-------------|
| Erick Armijos | tickets/ (FE+BE), ValidatorFactory | Módulo Tickets completo: state machine, validadores, repository, service, componentes, hooks, tests RBAC |
| Juan Pérez | config/, core/, authentication/ (FE+BE) | Core (BaseRepository, BaseValidator, RBAC), Auth (User model, JWT, verificación), integración App.tsx |
| Elías Rubio | notifications/, realtime/, SocketClient | Módulo Notificaciones: 3 estrategias, factory, service, templates email, Channels consumers, WebSocket |
| Jahir Cajas | catalog/, public/, core/ui/, index.css | Catálogo (Service model, CRUD, imágenes), sitio público, UI kit completo, design system |
| Jairo Rodríguez | reports/, dashboards/, DevOps | Reportes (exportadores CSV/Excel/PDF), dashboards, Jenkinsfile, Docker, CI/CD, DEPLOYMENT.md |

---

## 11. Apéndices

### Apéndice A — Formularios de Aceptación
- Sprint 1 — firmado 31 mayo 2025
- Sprint 2 — firmado 21 junio 2025
- Sprint 3 — firmado 26 julio 2025
- Sprint 4 — firmado 16 agosto 2025

### Apéndice B — Video de Presentación
- Demo de 10 minutos mostrando los 3 roles y cumplimiento de requisitos funcionales

### Apéndice C — Entorno de Producción
- Frontend: https://app.sassblum.example.com
- Backend API: https://api.sassblum.example.com/api/
- Django Admin: https://api.sassblum.example.com/admin/
- Health Check: https://api.sassblum.example.com/health/

### Apéndice D — Evidencia de Gestión
- GitHub Projects: https://github.com/edarmijo/SassBlumRedise-oWeb/projects

### Apéndice E — Auditoría de Código
- REPORTE_AUDITORIA_TOTAL.md — 30 hallazgos, todos corregidos
- SKILL_AUDITORIA.md — Skill de auditoría continua

### Apéndice F — Requerimientos del Cliente (Reunión 24 Junio 2026)
- 9 de 10 cambios implementados
- Ver `docs/REQUERIMIENTOS_CLIENTE.md` para detalle completo

### Apéndice G — Archivos de Contexto para LLMs
- AGENTS.md — Contexto del proyecto para cualquier LLM
