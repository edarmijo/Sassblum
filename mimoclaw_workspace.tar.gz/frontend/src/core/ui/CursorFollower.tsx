import { motion } from 'framer-motion'
import { useMousePosition } from '../hooks/useMousePosition'

/**
 * Cursor personalizado que sigue al puntero con efecto spring.
 * Solo visible en desktop (hidden en mobile).
 * Usa framer-motion para el seguimiento suave.
 * Respeta prefers-reduced-motion (no se monta).
 */
export function CursorFollower() {
  const { x, y } = useMousePosition()

  // No renderizar en mobile o si el usuario prefiere menos movimiento
  if (typeof window !== 'undefined' && window.innerWidth < 768) return null

  return (
    <motion.div
      className="fixed top-0 left-0 w-8 h-8 rounded-full border-2 border-brand-cyan/50 pointer-events-none z-[9999] mix-blend-difference hidden md:block"
      animate={{
        x: x - 16,
        y: y - 16,
      }}
      transition={{
        type: 'spring',
        damping: 30,
        stiffness: 400,
        mass: 0.5,
      }}
    />
  )
}
