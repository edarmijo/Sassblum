import { useState } from 'react'
import { Filter, X } from 'lucide-react'
import { useReports } from '../../hooks/useReports'
import { ExportButton } from '../ExportButton'
import { Button } from '../../../../core/ui/button'
import { Input } from '../../../../core/ui/input'
import { Label } from '../../../../core/ui/label'
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '../../../../core/ui/select'
import type { ReportFilters, ReportFormat } from '../../interfaces/IReportsService'

const ESTADOS = ['Nuevo', 'EnProceso', 'EnEspera', 'Resuelto', 'Cerrado']

/**
 * H#6 (cliente): Reports dashboard with advanced filters.
 * Filters: RUC, cliente nombre, rango de fechas, estado, técnico asignado.
 * Export: PDF, Excel, CSV.
 *
 * Vicky Pinto: "Voy a filtrar por RUC y por mes, del 1 al 30 de junio,
 * y me va a presentar la pantalla de búsqueda y de ahí puedo descargar en PDF o Excel."
 */
export function ReportsDashboard() {
  const [filters, setFilters] = useState<ReportFilters>({})
  const [showFilters, setShowFilters] = useState(false)
  const { summary, isLoading, error, exportReport, refresh } = useReports(filters)

  const updateFilter = <K extends keyof ReportFilters>(key: K, value: ReportFilters[K]) => {
    setFilters((f) => ({ ...f, [key]: value || undefined }))
  }

  const clearFilters = () => {
    setFilters({})
  }

  const hasFilters = Object.values(filters).some(Boolean)

  if (isLoading) return <p className="text-sm text-muted-foreground py-8">Cargando reporte…</p>
  if (error) return <p className="text-sm text-destructive">{error}</p>
  if (!summary) return null

  const maxEstado = Math.max(1, ...Object.values(summary.porEstado))

  return (
    <section className="space-y-6">
      <header className="flex items-center justify-between gap-4 flex-wrap">
        <div>
          <h2 className="text-xl font-bold text-foreground">Reportes</h2>
          <p className="text-sm text-muted-foreground mt-0.5">
            Resumen de tickets del sistema{hasFilters ? ' (filtrado)' : ''}.
          </p>
        </div>
        <div className="flex gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setShowFilters((s) => !s)}
            className={showFilters ? 'bg-brand-cyan/10' : ''}
          >
            <Filter className="h-4 w-4 mr-1" />Filtros
            {hasFilters && <span className="ml-1 h-2 w-2 rounded-full bg-brand-cyan" />}
          </Button>
          <ExportButton onExport={(fmt: ReportFormat) => exportReport(fmt)} />
        </div>
      </header>

      {/* H#6: Advanced filters panel */}
      {showFilters && (
        <div className="bg-slate-50 border border-border rounded-xl p-4 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-semibold text-foreground">Filtros avanzados</h3>
            {hasFilters && (
              <Button variant="ghost" size="sm" onClick={clearFilters}>
                <X className="h-3 w-3 mr-1" />Limpiar
              </Button>
            )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            <div className="space-y-1.5">
              <Label htmlFor="f-ruc">RUC del cliente</Label>
              <Input
                id="f-ruc"
                value={filters.clienteRuc ?? ''}
                onChange={(e) => updateFilter('clienteRuc', e.target.value)}
                placeholder="Ej: 0991234567001"
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="f-cliente">Nombre / Email cliente</Label>
              <Input
                id="f-cliente"
                value={filters.clienteNombre ?? ''}
                onChange={(e) => updateFilter('clienteNombre', e.target.value)}
                placeholder="Ej: Juan Pérez"
              />
            </div>
            <div className="space-y-1.5">
              <Label>Estado</Label>
              <Select value={filters.estado ?? ''} onValueChange={(v) => updateFilter('estado', v)}>
                <SelectTrigger>
                  <SelectValue placeholder="Todos los estados" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">Todos</SelectItem>
                  {ESTADOS.map((e) => <SelectItem key={e} value={e}>{e}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="f-desde">Fecha desde</Label>
              <Input
                id="f-desde"
                type="date"
                value={filters.fechaDesde ?? ''}
                onChange={(e) => updateFilter('fechaDesde', e.target.value)}
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="f-hasta">Fecha hasta</Label>
              <Input
                id="f-hasta"
                type="date"
                value={filters.fechaHasta ?? ''}
                onChange={(e) => updateFilter('fechaHasta', e.target.value)}
              />
            </div>
          </div>

          <div className="flex gap-2 pt-1">
            <Button size="sm" onClick={() => void refresh()} className="bg-brand-cyan hover:bg-brand-cyan-dark text-brand-navy">
              Aplicar filtros
            </Button>
          </div>
        </div>
      )}

      {/* KPI cards */}
      <div className="grid grid-cols-3 gap-3 sm:gap-4">
        <Kpi label="Total" value={summary.total} accent="text-foreground" />
        <Kpi label="Abiertos" value={summary.abiertos} accent="text-amber-600" />
        <Kpi label="Cerrados" value={summary.cerrados} accent="text-green-600" />
      </div>

      {/* By estado */}
      <div>
        <h3 className="text-sm font-semibold text-foreground mb-3">Por estado</h3>
        <div className="space-y-2.5">
          {Object.entries(summary.porEstado).map(([estado, n]) => (
            <div key={estado} className="flex items-center gap-3">
              <span className="text-xs text-muted-foreground w-24 shrink-0">{estado}</span>
              <div className="flex-1 bg-slate-100 rounded-full h-2.5 overflow-hidden">
                <div className="bg-brand-cyan-dark h-full rounded-full transition-[width] duration-500" style={{ width: `${(n / maxEstado) * 100}%` }} />
              </div>
              <span className="text-xs font-medium text-foreground w-8 text-right tabular-nums">{n}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

function Kpi({ label, value, accent = 'text-foreground' }: { label: string; value: number; accent?: string }) {
  return (
    <div className="bg-card border border-border rounded-xl p-4">
      <p className="text-xs uppercase tracking-wide text-muted-foreground">{label}</p>
      <p className={`text-2xl font-bold mt-1 tabular-nums ${accent}`}>{value}</p>
    </div>
  )
}
