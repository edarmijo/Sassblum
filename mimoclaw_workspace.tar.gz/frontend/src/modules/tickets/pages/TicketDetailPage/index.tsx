import { useState } from 'react'
import { ArrowLeft } from 'lucide-react'
import { TicketDetail } from '../../components/TicketDetail'
import { StatusChangeForm } from '../../components/StatusChangeForm'
import { useAuth } from '../../../auth/hooks/useAuth'
import { ticketService } from '../../services/TicketService'
import { useTicketDetail } from '../../hooks/useTickets'
import type { TicketEstado } from '../../interfaces/ITicketService'

interface TicketDetailPageProps {
  ticketId: string
  onBack?: () => void
}

/**
 * SRP: page wrapper around the TicketDetail component (S17), which already loads
 * the ticket + event timeline via useTicketDetail (DIP). This page only adds
 * page-level chrome (back navigation).
 *
 * H#3 (cliente): Includes StatusChangeForm for workers/admins to change
 * ticket status with mandatory observations for audit trail.
 */
export function TicketDetailPage({ ticketId, onBack }: TicketDetailPageProps) {
  const { user } = useAuth()
  const { ticket } = useTicketDetail(ticketId)
  const [refreshKey, setRefreshKey] = useState(0)
  const isStaff = user?.rol === 'TRABAJADOR' || user?.rol === 'ADMINISTRADOR'

  const handleStatusChange = async (newStatus: TicketEstado, comment: string) => {
    await ticketService.updateStatus(ticketId, newStatus, comment)
    setRefreshKey((k) => k + 1) // Trigger re-render to show new event
  }

  return (
    <section className="max-w-3xl mx-auto px-4 py-8 space-y-5">
      {onBack && (
        <button
          type="button"
          onClick={onBack}
          className="text-sm text-muted-foreground hover:text-brand-cyan-dark transition-colors inline-flex items-center gap-1.5 cursor-pointer"
        >
          <ArrowLeft className="h-4 w-4" /> Volver al historial
        </button>
      )}
      <div className="bg-card border border-border rounded-xl shadow-sm p-6">
        <TicketDetail key={refreshKey} ticketId={ticketId} />
      </div>

      {/* H#3 (cliente): Status change with observations for staff */}
      {isStaff && ticket && (
        <StatusChangeForm
          currentStatus={ticket.estado}
          onSubmit={handleStatusChange}
        />
      )}
    </section>
  )
}
